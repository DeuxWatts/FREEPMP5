<?php

namespace DeuxWatts\Plugins;

use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\Listener;
use jojoe77777\FormAPI\SimpleForm;

class Main extends PluginBase implements Listener {

    public function onEnable(): void
    {
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }

    /**
     * @param PlayerJoinEvent $event
     */
    public function onPlayerJoin(PlayerJoinEvent $event) {
        $player = $event->getPlayer();

        $form = new SimpleForm(function (Player $player, int $data = null) {
            if($data === null){
                return true;
            }
            switch($data){
                case 0:
                    $player->sendMessage("§l§aBon jeu sur Nom du Serveur");
                    break;
            }
        });

        $form->setTitle("JoinUI");
        $form->setContent("Ce texte est modifiable dans le fichier config | Plugin Data du serveur !");
        $form->addButton("§l§aCompris !");
        $player->sendForm($form);
    }
}